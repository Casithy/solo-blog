title: Ant 中文文档以及动态修改配置文件脚本
date: '2020-09-27 09:38:05'
updated: '2020-09-27 09:38:05'
tags: [Ant]
permalink: /articles/2020/09/27/1601170685194.html
---
工作中遇到这么一个问题，要求是动态替换配置文件中某个键值的value，每一次打包执行build.xml时，将配置文件中的键值替换一下。

```xml
<!-- 使用 javascript 生成动态值 -->
<script language="javascript">
	<![CDATA[
		var random = "",
		    range = 16,
	            hash = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

		for(var i=0; i<range; i++){
		    var index = Math.round(Math.random() * (hash.length-1));
		    random += hash.substring(index,index+1);
		}

		project.setProperty("random", random);
	]]>
</script>
<!-- 将配置文件中的配置在 build.xml 中全局变量化，目的是取出旧的键值 -->
<property file="${server.path}/WEB-INF/configuration/application.properties" />

<!-- 用新生成的键值替换旧的键值 -->
<replace file="${server.path}/WEB-INF/configuration/application.properties">
	<replacefilter token="${old.random}" value="${random}"/>
</replace>
```

这样便实现了配置文件的动态生成与替换，由于ant仅仅支持字符串替换，所以必须先将原来的字符串取出再进行替换。

另附：ant 中文文档 [antmanual.rar](https://b3logfile.com/file/2020/09/antmanual-e6b43c20.rar)
